/**
 * 
 */
package com.wallet.mod4.entidades;

/**
 * 
 */
public interface AccountInterface {
	
	public String getAccountNumber();
	public double getBalance();
	public void updateBalance(double amount);
	
}

